package com.example.golf;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.golf.Main.Data.Data;
import com.example.golf.Main.Save;
import com.example.golf.Main.TestFunctions;

import java.util.HashMap;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class AddPoint4 extends AppCompatActivity {
    private Save save = new Save();
    private TestFunctions testFunctions = new TestFunctions();
    private Data data = MainActivity.getData();
    private int playerFocus;
    private HashMap<Integer,Integer> score = new HashMap<>();
    private int par = 4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        playerFocus = 1;
        resetPoints();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_point4);
    }
    public void resetPoints(){
        for (int i = 1; i <= 4; i++) {
            score.put(i,par);
        }
    }
    public void add4(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        score.put(playerFocus,score.get(playerFocus)+1);
        button.setText(String.valueOf(score.get(playerFocus)));
    }
    public void remove4(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        int score1 = score.get(playerFocus);
        if(score1 > 4){
            score.put(playerFocus,score1-1);
            button.setText(String.valueOf(score.get(playerFocus)));}
    }
    public void chooseFocus4(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.NORMAL);
        switch (view.getId()){
            case R.id.Player1:
                playerFocus = 1;
                break;
            case R.id.player2:
                playerFocus = 2;
                break;
            case R.id.player3:
                playerFocus = 3;
                break;
            case R.id.player4:
                playerFocus = 4;
                break;
        }
        button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.BOLD);
    }
    public void next4(View view){
        save.next(view,4);
        resetPoints();
        Button button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.NORMAL);
        playerFocus = 1;
        button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.BOLD);
    }
    public void priev4(View view){
        save.priev(view,4);
    }
}