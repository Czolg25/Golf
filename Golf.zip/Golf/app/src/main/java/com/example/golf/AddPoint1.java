package com.example.golf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.golf.Main.Data.Data;
import com.example.golf.Main.Save;
import com.example.golf.Main.TestFunctions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class AddPoint1 extends AppCompatActivity {
    @SuppressLint("NewApi")
    private Save save = new Save();
    private TestFunctions testFunctions = new TestFunctions();
    private Data data = MainActivity.getData();
    private int playerFocus;
    private int par = 4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        playerFocus = 1;
        for (int i = 1; i <= 4; i++) {
            data.scoreTemp.put(i,par);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_point1);
    }


    public void add1(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        data.scoreTemp.put(playerFocus,data.scoreTemp.get(playerFocus)+1);
        button.setText(String.valueOf(data.scoreTemp.get(playerFocus)));
    }
    public void remove1(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        int score1 = data.scoreTemp.get(playerFocus);
        if(score1 > 4){
            data.scoreTemp.put(playerFocus,score1-1);
            button.setText(String.valueOf(data.scoreTemp.get(playerFocus)));}
    }
    public void next1(View view){
        save.next(view,1);
    }
    public void priev1(View view){
        save.priev(view,1);
    }
}