package com.example.golf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.golf.Main.Data.Data;
import com.example.golf.Main.TestFunctions;

import java.util.Arrays;
import java.util.List;

public class Players4 extends AppCompatActivity {
    private Data data =MainActivity.getData();
    private TestFunctions testFunctions = new TestFunctions();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players4);
    }

    public void createPlayers4(View view) {
        Intent intent = null;
        data.setI(1);
        View root = view.getRootView();
        EditText editText1 = root.findViewById(R.id.HCP1);
        EditText editText2 = root.findViewById(R.id.HCP2);
        EditText editText3 = root.findViewById(R.id.HCP3);
        EditText editText4 = root.findViewById(R.id.HCP4);
        switch (data.getNumberPlayers()){
            case 4:
                if(testText(editText1.getText().toString())&&testText(editText2.getText().toString())&&testText(editText3.getText().toString())&&testText(editText4.getText().toString())){
                    List<String> hcp = Arrays.asList(editText1.getText().toString(),editText2.getText().toString(),editText3.getText().toString(),editText4.getText().toString());
                    testFunctions.addHcp(hcp);
                    intent = new Intent(Players4.this,AddPoint4.class);
                }
        }
        if(intent != null){
            startActivity(intent);
        }
    }
    private boolean testText(String text){
        if(testFunctions.testText(text)){
            if(text.contains("HCP gracza")){
                return false;
            }
            return true;
        }else {
            return false;
        }
    }
}