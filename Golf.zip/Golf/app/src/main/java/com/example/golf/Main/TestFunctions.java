package com.example.golf.Main;


import android.view.View;
import android.widget.Button;

import com.example.golf.Main.Data.Data;
import com.example.golf.MainActivity;
import com.example.golf.R;

import java.util.List;

public class TestFunctions {
    private Data data = MainActivity.getData();

    public boolean testText(String text){
        if(text == null) return false;
        text = text.replace(" ","");
        if(text.equals("")) return false;
        return true;
    }
    public Button getButton(int i, View view){
        switch (i){
            case 1:
                return view.getRootView().findViewById(R.id.Player1);
            case 2:
                return view.getRootView().findViewById(R.id.player2);
            case 3:
                return view.getRootView().findViewById(R.id.player3);
            case 4:
                return view.getRootView().findViewById(R.id.player4);
        }
        return view.getRootView().findViewById(R.id.Player1);
    }

    public void addHcp(List<String> hcp){
        int player = 1;
        for (String s : hcp) {
            data.addHcp(player,s);
            player++;
        }
    }
}
