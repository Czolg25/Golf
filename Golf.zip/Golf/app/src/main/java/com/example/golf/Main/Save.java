package com.example.golf.Main;

import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.example.golf.Main.Data.Data;
import com.example.golf.MainActivity;
import com.example.golf.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class Save {
    private Data data = MainActivity.getData();
    private TestFunctions testFunctions = new TestFunctions();
    private String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)+"/DigitalZombe/golf";
    private String fileName = "file.json";

    public void next(View view, int idMaxButton){
        if(data.getI() < 18){
            save(view,idMaxButton);
            dataToJSON(data.getI());
            reset(view,data.getI()+1,idMaxButton);
        }else {
            save(view,idMaxButton);
            dataToJSON(data.getI());
        }
    }
    public void priev(View view,int idMaxButton){
        if(data.getI() > 1){
            save(view,idMaxButton);
            dataToJSON(data.getI());
            reset(view,data.getI()-1,idMaxButton);
        }
    }
    private void save(View view, int idMaxButton){//id is not in view
        List<String> score = new ArrayList<>();
        for (int i = 1; i <= idMaxButton; i++) {
            Button button = testFunctions.getButton(i,view);
            score.add(button.getText().toString());
        }
        data.setScore(data.getI(), score);
    }
    private void reset(View view,int dolek,int idMaxButton){
        data.setI(dolek);
        TextView dolekText = view.getRootView().findViewById(R.id.dolek);
        dolekText.setText("Dołek "+dolek);
        List <String> score = data.getScore(dolek);
        boolean spr = score != null;
        for (int i = 1; i <= idMaxButton; i++) {
            Button button = testFunctions.getButton(i,view);
            if(spr){
                button.setText(score.get(i-1));
                data.scoreTemp.put(i, Integer.valueOf(score.get(i-1)));
            }else {
                data.scoreTemp.put(i,4);
                button.setText("4");}
        }
    }
    private void dataToJSON(int i){
        if(createDir()){
            try {
                toJson(i);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private boolean createDir(){
        File file = new File(path);
        if(!file.exists()){
            try {
                return file.mkdir();
            }catch (Exception e){
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }
    private void toJson(int i) throws Exception{
        String json = path+"/"+fileName;
        FileWriter file = new FileWriter(json);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("turnament",data.getTurnamentName());
        jsonObject.put("course", data.getCourseName());
        jsonObject.put("player."+i+".hcp",data.getHcp(i));
        jsonObject.put("score."+i,data.getScore(i));
        file.write(jsonObject.toString());
    }
}
