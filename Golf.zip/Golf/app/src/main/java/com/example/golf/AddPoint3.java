package com.example.golf;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.golf.Main.Data.Data;
import com.example.golf.Main.Save;
import com.example.golf.Main.TestFunctions;

import java.util.HashMap;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class AddPoint3 extends AppCompatActivity {
    private Save save = new Save();
    private TestFunctions testFunctions = new TestFunctions();
    private Data data = MainActivity.getData();
    private int playerFocus;
    private HashMap<Integer,Integer> score = new HashMap<>();
    private int par = 4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        playerFocus = 1;
        resetPoints();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_point3);
    }

    public void resetPoints(){
        for (int i = 1; i <= 4; i++) {
            score.put(i,par);
        }
        Log.d("Hash",score+"");
    }

    public void add3(View view){
        Log.d("Hash",score+"");
        Button button = testFunctions.getButton(playerFocus,view);
        score.put(playerFocus,score.get(playerFocus)+1);
        button.setText(String.valueOf(score.get(playerFocus)));
    }
    public void remove3(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        int score1 = score.get(playerFocus);
        if(score1 > 4){
            score.put(playerFocus,score1-1);
            button.setText(String.valueOf(score.get(playerFocus)));}
    }
    public void chooseFocus3(View view){
        Button button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.NORMAL);
        switch (view.getId()){
            case R.id.Player1:
                playerFocus = 1;
                break;
            case R.id.player2:
                playerFocus = 2;
                break;
            case R.id.player3:
                playerFocus = 3;
                break;
        }
        button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.BOLD);
    }
    public void next3(View view){
        save.next(view,3);
        resetPoints();
        Button button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.NORMAL);
        playerFocus = 1;
        button = testFunctions.getButton(playerFocus,view);
        button.setTypeface(null, Typeface.BOLD);
    }
    public void priev3(View view){
        save.priev(view,3);
    }
}