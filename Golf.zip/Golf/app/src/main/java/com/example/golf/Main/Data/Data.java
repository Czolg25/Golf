package com.example.golf.Main.Data;


import java.util.HashMap;
import java.util.List;

public class Data {
    private String turnamentName;
    private String courseName;
    private int numberPlayers;
    private int i;//iterlize number
    private HashMap<Integer,String> hcp = new HashMap<>();//int is player's number
    private HashMap<Integer, List<String>> score = new HashMap<>();//list is player's score
    public HashMap<Integer,Integer> scoreTemp = new HashMap<>();

    public String getTurnamentName() {
        return turnamentName;
    }                               
    public void setTurnamentName(String turnamentName) {
        this.turnamentName = turnamentName;
    }

    public String getCourseName() {
        return courseName;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getNumberPlayers() {
        return numberPlayers;
    }
    public void setNumberPlayers(int numberPlayers) {
        this.numberPlayers = numberPlayers;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    public void addHcp(int player,String hcp){
        this.hcp.put(player,hcp);
    }
    public String getHcp(int player) {
        return hcp.get(player);
    }

    public void setScore(int i,List<String> score){
        this.score.put(i,score);
    }

    public List<String> getScore(int i) {
        return score.get(i);
    }

}
