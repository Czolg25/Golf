package com.example.golf.Main.Data;


public class Data {
    private String turnamentName;
    private String courseName;

    public String getTurnamentName() {
        return turnamentName;
    }                               
    public void setTurnamentName(String turnamentName) {
        this.turnamentName = turnamentName;
    }

    public String getCourseName() {
        return courseName;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
