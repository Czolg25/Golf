package com.example.golf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.golf.Main.Data.Data;

public class NumberPlayer extends AppCompatActivity {
    private Data data = MainActivity.getData();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number_player);
    }

    public void onClickChoosePlayer(View view) {
        Intent intent = null;
        switch (view.getId()){
            case R.id.choosePlayer1:
                data.setNumberPlayers(1);
                intent = new Intent(NumberPlayer.this,Players1.class);
                break;
            case R.id.choosePlayer2:
                data.setNumberPlayers(2);
                intent = new Intent(NumberPlayer.this,Players2.class);
                break;
            case R.id.choosePlayer3:
                data.setNumberPlayers(3);
                intent = new Intent(NumberPlayer.this,Players3.class);
                break;
            case R.id.choosePlayer4:
                data.setNumberPlayers(4);
                intent = new Intent(NumberPlayer.this,Players4.class);
                break;
        }
        if(intent!=null){
            startActivity(intent);
        }
    }
}